﻿namespace Library.Models
{
    public class BookingData
    {
        public Guid? BookId { get; set; }
        public virtual Book Book { get; set; }
        public Guid UserId { get; set; }
        public virtual User User { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
    }
}

