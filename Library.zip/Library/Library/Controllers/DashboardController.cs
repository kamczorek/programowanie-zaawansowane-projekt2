﻿using Library.DTO;
using Library.DTO.Account;
using Library.DTO.Book;
using Library.DTO.Rental;
using Library.DTO.Reservation;
using Library.DTO.User;
using Library.Models;
using Library.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        private readonly UserManager<User> _userManager;
        private readonly RoleManager<IdentityRole<Guid>> _roleManager;
        private readonly IBookService _bookService;
        private readonly IReservationService _reservationService;
        private readonly IRentalService _rentalService;
        public DashboardController(IBookService bookService, UserManager<User> userManager, 
            RoleManager<IdentityRole<Guid>> roleManager, IReservationService reservationService, IRentalService rentalService)
        {
            _bookService = bookService;
            _userManager = userManager;
            _roleManager = roleManager;
            _reservationService = reservationService;
            _rentalService = rentalService;
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> Index()
        {
            var list = await _bookService.GetAllBooksAsync();
            return View(list);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public IActionResult CreateBook()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> CreateBook(BookItemDto request)
        {
            if (ModelState.IsValid)
            {
                await _bookService.CreateBookAsync(request);
                return RedirectToAction("Index");
            }

            return View(request);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}, {nameof(Role.Admin)}")]
        public async Task<IActionResult> GetUsers(Role role)
        {
            var users = await _userManager.GetUsersInRoleAsync(role.ToString());
            var usersDto = users.Select(x => new UserItemDto
            {
                Id = x.Id,
                Name = x.Name,
                LastName = x.LastName,
                City = x.City,
                Street = x.Street,
                Building = x.Building,
                Apartment = x.Apartment
            });
            return View(usersDto);
        }

        [Authorize(Roles = $"{nameof(Role.Admin)}")]
        public async Task<IActionResult> DeleteUser(Guid id)
        {
            var user = _userManager.Users.Where(x => x.Id == id).First();
            await _userManager.DeleteAsync(user);
            return RedirectToAction("GetUsers");
        }

        [Authorize(Roles = $"{nameof(Role.Admin)}")]
        public IActionResult CreateEmployee()
        {
            return View();
        }

        [HttpPost]
        [Authorize(Roles = $"{nameof(Role.Admin)}")]
        public async Task<IActionResult> CreateEmployee(SignUpDto request)
        {
            if (ModelState.IsValid)
            {
                var existingUser = await _userManager.FindByEmailAsync(request.Email);
                if (existingUser != null)
                {
                    ModelState.AddModelError("Email", "Użytkownik o takim adresie e-mail już istnieje");
                    return View(request);
                }

                var user = new User
                {
                    Name = request.Name,
                    LastName = request.LastName,
                    Email = request.Email,
                    UserName = request.Email,
                    City = request.City,
                    Street = request.Street,
                    Building = request.Building,
                    Apartment = request.Apartment
                };

                var registeredUser = await _userManager.CreateAsync(user, request.Password);
                if (registeredUser.Succeeded)
                {
                    await GiveRoleToUser(user, Role.Employee.ToString());
                    return RedirectToAction("GetUsers");
                }
            }

            return View(request);
        }

        [Authorize(Roles = $"{nameof(Role.Admin)}")]
        public async Task<IActionResult> UpdateUser(Guid id)
        {
            var user = _userManager.Users.Where(x => x.Id == id).First();
            var updateUserDto = new UpdateUserDto
            {
                Id = user.Id,
                Name = user.Name,
                LastName = user.LastName,
                City = user.City,
                Street = user.Street,
                Building = user.Building,
                Apartment = user.Apartment,
                Email = user.Email,
                Role = await GetRole(user)
            };

            return View(updateUserDto);
        }

        [Authorize(Roles = $"{nameof(Role.Admin)}")]
        [HttpPost]
        public async Task<IActionResult> UpdateUser(UpdateUserDto request)
        {
            var user = _userManager.Users.Where(x => x.Id == request.Id).First();
            user.Street = request.Street;
            user.Building = request.Building;
            user.Apartment = request.Apartment;
            user.City = request.City;
            user.Name = request.Name;
            user.LastName = request.LastName;
            user.Email = request.Email;
            await _userManager.UpdateAsync(user);

            var oldRole = await GetRole(user);
            await _userManager.RemoveFromRoleAsync(user, oldRole);
            await GiveRoleToUser(user, request.Role);
            return RedirectToAction("GetUsers");
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public IActionResult GetUserHistory(Guid id)
        {
            var user = _userManager.Users.Where(x => x.Id == id).First();
            var history = new HistoryDto
            {
                Rentals = user.Rentals.Select(x => new RentalItemDto
                {
                    Id = x.Id,
                    BookId = x.BookId,
                    UserId = x.UserId,
                    Name = x.User.Name,
                    LastName = x.User.LastName,
                    BookInfo = x.BookInfo,
                    CoverImage = x.Book.CoverImage,
                    StartDate = x.DateFrom,
                    EndDate = x.DateTo,
                    Status = x.Status,
                    BookStatus = x.Book.Status
                }).ToList(),

                Reservations = user.Reservations.Select(x => new ReservationItemDto
                {
                    Id = x.Id,
                    BookId = x.BookId,
                    UserId = x.UserId,
                    Name = x.User.Name,
                    LastName = x.User.LastName,
                    Title = x.Book.Title,
                    Author = x.Book.Author,
                    Type = x.Book.Type,
                    CoverImage = x.Book.CoverImage,
                    StartDate = x.DateFrom,
                    EndDate = x.DateTo
                }).ToList()
            };

            return View(history);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> GetReservations()
        {
            var reservations = await _reservationService.GetAllReservationsAsync();
            return View(reservations);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> GetRentals()
        {
            var rentals = await _rentalService.GetAllRentalsAsync();
            return View(rentals);
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> UpdateBook(Guid id)
        {
            var book = await _bookService.GetBookByIdAsync(id);
            return View(book);
        }

        [HttpPost]
        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> UpdateBook(BookItemDto request)
        {
            await _bookService.UpdateBookAsync(request);
            return RedirectToAction("ViewBook", "Book", new { id = request.Id });
        }

        private async Task GiveRoleToUser(User user, string role)
        {
            if (!await _roleManager.RoleExistsAsync(role))
            {
                await _roleManager.CreateAsync(new IdentityRole<Guid>(role));
            }
            await _userManager.AddToRoleAsync(user, role);
        }

        private async Task<string> GetRole(User user)
        {
            var roles = await _userManager.GetRolesAsync(user);
            return roles.FirstOrDefault();
        }
    }
}

