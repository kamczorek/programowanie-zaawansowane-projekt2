﻿using Library.DTO;
using Library.DTO.Book;
using Library.DTO.Reservation;
using Library.Models;
using Library.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Library.Controllers
{
    [Authorize]
    public class ReservationController : Controller
    {
        private readonly IReservationService _reservationService;
        public ReservationController(IReservationService reservationService)
        {
            _reservationService = reservationService;
        }

        [HttpPost]
        [Authorize(Roles = $"{nameof(Role.User)}")]
        public async Task<IActionResult> Create(CreateReservationDto request)
        {
            if (request.EndDate.Date < request.StartDate.Date)
            {
                TempData["ErrorMessage"] = "Data początkowa nie może być większa od daty końcowej.";
                return RedirectToAction("ViewBook","Book", new {id = request.Id});
            }

            var reservedDates = await _reservationService.GetReservedAndRentedDatesAsync(request.Id);

            foreach (var reservedDate in reservedDates)
            {
                if (request.StartDate.Date >= reservedDate.StartDate.Date && request.StartDate.Date <= reservedDate.EndDate.Date)
                {
                    TempData["ErrorMessage"] = "W tym okresie książka jest zajęta.";
                    return RedirectToAction("ViewBook", "Book", new { id = request.Id });
                }

                if (request.EndDate.Date >= reservedDate.StartDate.Date && request.EndDate.Date <= reservedDate.EndDate.Date)
                {
                    TempData["ErrorMessage"] = "W tym okresie książka jest zajęta.";
                    return RedirectToAction("ViewBook", "Book", new { id = request.Id });
                }
            }

            var currentUserId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            request.UserId = currentUserId;
            await _reservationService.CreateAsync(request);
            return RedirectToAction("Index", "Home");
        }

        [Authorize(Roles = $"{nameof(Role.Employee)}")]
        public async Task<IActionResult> Decide(Guid id, bool decision)
        {
            await _reservationService.MoveReservationToRentalAsync(id, decision);
            if(decision)
            {
                return RedirectToAction("GetRentals", "Dashboard");                
            }
            return RedirectToAction("GetReservations", "Dashboard");

        }
    }
}

