﻿using Library.DTO;
using Library.DTO.Book;
using Library.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Library.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IBookService _bookService;
        public HomeController(IBookService bookService)
        {
            _bookService = bookService;
        }
        public async Task<IActionResult> Index()
        {
            var model = new HomeBooksDto();
            model.LatestBooks = await _bookService.GetLatestBooksAsync();
            model.AllBooks = await _bookService.GetAllBooksAsync();
            return View(model);
        }

        public async Task<string> UploadFile(IFormFile file)
        {
            var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), "Files\\");

            string fileName = Guid.NewGuid() + "-" + file.FileName.Replace("\"", "");
            var imagePath = Path.Combine(pathToSave, fileName);

            await using var stream = new FileStream(imagePath, FileMode.Create);
            await file.CopyToAsync(stream);

            return imagePath;
        }

        public IActionResult DisplayImage(string imagePath)
        {
            if (System.IO.File.Exists(imagePath))
            {
                var imageFileStream = new FileStream(imagePath, FileMode.Open, FileAccess.Read);
                return File(imageFileStream, "image/jpeg");
            }
            else
            {
                return NotFound();
            }
        }
    }
}
