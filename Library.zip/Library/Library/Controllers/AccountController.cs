﻿using Library.DTO.Account;
using Library.DTO.Rental;
using Library.DTO.Reservation;
using Library.DTO.User;
using Library.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace Library.Controllers
{
	public class AccountController : Controller
	{
		private readonly UserManager<User> _userManager;
		private readonly RoleManager<IdentityRole<Guid>> _roleManager;
		private readonly SignInManager<User> _signInManager;

		public AccountController(UserManager<User> userManager,
			RoleManager<IdentityRole<Guid>> roleManager,
			SignInManager<User> signInManager)
		{
			_userManager = userManager;
			_roleManager = roleManager;
			_signInManager = signInManager;
		}

		public IActionResult Register()
		{
			return View();
		}

		[HttpPost]
		public async Task<IActionResult> Register(SignUpDto request)
		{
			var existingUser = await _userManager.FindByEmailAsync(request.Email);
			if (existingUser != null)
			{
				ModelState.AddModelError("Email", "Użytkownik o takim adresie e-mail już istnieje");
				return View(request);
			}

			var user = new User
			{
				Name = request.Name,
				LastName = request.LastName,
				Email = request.Email,
				UserName = request.Email,
				City = request.City,
				Street = request.Street,
				Building = request.Building,
				Apartment = request.Apartment
			};

			var registeredUser = await _userManager.CreateAsync(user, request.Password);
			if (registeredUser.Succeeded)
			{
				await GiveRoleToUser(user, request.Password);
			}

			return RedirectToAction(nameof(Login));
		}

		public async Task<IActionResult> Login()
		{
			if (_signInManager.IsSignedIn(User))
			{
				return RedirectToAction("Index", "Home");
			}
			return View();
		}

		[HttpPost]
		public async Task<IActionResult> Login(LoginDto request)
		{
			var existingUser = await _userManager.FindByEmailAsync(request.Email);
			if (existingUser == null)
			{
				ModelState.AddModelError("Email", "Użytkownik o takim adresie e-mail nie istnieje");
			}

			if (await _userManager.CheckPasswordAsync(existingUser, request.Password))
			{
				var result = await _signInManager.PasswordSignInAsync(request.Email, request.Password, true, lockoutOnFailure: false);
				if (result.Succeeded)
				{
					return RedirectToAction("Index", "Home");
				}
			}

			ModelState.AddModelError("Password", "Niepoprawne hasło");
			return View(request);
		}

		[Authorize]
        public IActionResult GetUserHistory()
        {
            var currentUserId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var user = _userManager.Users.Where(x => x.Id == currentUserId).First();
            var history = new HistoryDto
            {
                Rentals = user.Rentals.Select(x => new RentalItemDto
                {
                    Id = x.Id,
                    BookId = x.BookId,
                    UserId = x.UserId,
                    Name = x.User.Name,
                    LastName = x.User.LastName,
                    BookInfo = x.BookInfo,
                    CoverImage = x.Book.CoverImage,
                    StartDate = x.DateFrom,
                    EndDate = x.DateTo,
                    Status = x.Status,
					BookStatus = x.Book.Status
                }).ToList(),

                Reservations = user.Reservations.Select(x => new ReservationItemDto
                {
                    Id = x.Id,
                    BookId = x.BookId,
                    UserId = x.UserId,
                    Name = x.User.Name,
                    LastName = x.User.LastName,
                    Title = x.Book.Title,
                    Author = x.Book.Author,
                    Type = x.Book.Type,
                    CoverImage = x.Book.CoverImage,
                    StartDate = x.DateFrom,
                    EndDate = x.DateTo
                }).ToList()
            };

            return View(history);
        }

        private async Task GiveRoleToUser(User user, string password)
		{
			Role role;
			if (password == "Admin123@")
			{
				role = Role.Admin;						
			}
			else
			{
				role = Role.User;
			}

			if (!await _roleManager.RoleExistsAsync(role.ToString()))
			{
				await _roleManager.CreateAsync(new IdentityRole<Guid>(role.ToString()));
			}
			await _userManager.AddToRoleAsync(user, role.ToString());

		}

		[Authorize]
		public async Task<IActionResult> Logout()
		{
			await _signInManager.SignOutAsync();
			return RedirectToAction("Login");
		}
    }
}

