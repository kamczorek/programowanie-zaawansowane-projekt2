﻿using Library.DTO.Reservation;

namespace Library.Services.Interfaces
{
    public interface IReservationService
    {
        Task CreateAsync(CreateReservationDto request);
        Task<IEnumerable<ReservationItemDto>> GetAllReservationsAsync();
        Task MoveReservationToRentalAsync(Guid reservationId, bool decision);
        Task<IEnumerable<ReservedPeriod>> GetReservedAndRentedDatesAsync(Guid bookId);
    }
}

