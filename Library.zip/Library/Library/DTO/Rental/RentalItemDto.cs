﻿using Library.Models;

namespace Library.DTO.Rental
{
    public class RentalItemDto
    {
        public Guid Id { get; set; }
        public Guid? BookId { get; set; }
        public Guid UserId { get; set; }
        public string Name { get; set; }
        public string LastName { get; set; }
        public string BookInfo { get; set; }
        public string CoverImage { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public RentalStatus Status { get; set; }
        public BookStatus BookStatus { get; set; }
    }
}

