﻿using System.ComponentModel.DataAnnotations;
namespace Library.DTO.Rental
{
    public class CreateRentalDto
    {
        public Guid BookId { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Początek rezerwacji")]
        public DateTime StartDate { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Koniec rezerwacji")]
        public DateTime EndDate { get; set; }
    }
}

