﻿using System.ComponentModel.DataAnnotations;

namespace Library.DTO.Reservation
{
    public class CreateReservationDto
    {
        public Guid Id { get; set; }
        public Guid UserId { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Początek rezerwacji")]
        public DateTime StartDate { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Koniec rezerwacji")]
        public DateTime EndDate { get; set; }
    }
}

