﻿using Library.Models;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Library.DTO.Book
{
    public class BookItemDto
    {
        public Guid Id { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [DisplayName("Tytuł")]
        public string Title { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [DisplayName("Streszczenie")]
        public string Summary { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [DisplayName("Autorzy")]
        public string Author { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [DisplayName("Gatunek")]
        public string Type { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [DisplayName("Link do okładki")]
        public string CoverImage { get; set; }
        public BookStatus Status { get; set; }

        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Początek rezerwacji")]
        public DateTime StartDate { get; set; }
        [Required(ErrorMessage = "To pole jest wymagane")]
        [Display(Name = "Koniec rezerwacji")]
        public DateTime EndDate { get; set; }
    }
}

