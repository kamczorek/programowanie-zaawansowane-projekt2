﻿namespace Library.DTO.Book
{
    public class BookBasket
    {
        public Guid BookId { get; set; }
        public string Title { get; set; }
        public string BookCover { get; set; }
        public string Author { get; set; }
    }
}

