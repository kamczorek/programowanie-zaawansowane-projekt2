﻿using Library.Models;

namespace Library.Repositories.Interfaces
{
    public interface IRentalRepository
    {
        Task CreateRentalAsync(Rental rental);
        Task<IEnumerable<Rental>> GetAllRentalsAsync();
        Task<Rental> GetRentalByIdAsync(Guid id);
        Task UpdateRentalAsync(Rental rental);
        Task<IEnumerable<Rental>> GetRentalsByBookIdAsync(Guid bookId);
    }
}

